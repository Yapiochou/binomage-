<?=$this->extend('layouts/acceuil')?>
<!-- [$this->extend('route du fichier template ou principale )] -->
<!-- 'fichier acceuil' c'est le fichier qui contient la page principale -->
<?=$this->section('content')?>

<!-- Affichage des erreurs de validation -->
 <code>
    <?php if (isset($validation)): ?>
        <div class="alert alert-danger">
            <?= $validation->listErrors() ?>
        </div>
    <?php endif; ?>
 </code><br><br>
<h2>Formulaire 📝</h2>
<br>

    <!-- Formulaire d'ajout d'un filleul -->
    <form action="adfilleul" method="post" enctype="multipart/form-data" class="container mt-4 p-4 border rounded shadow-sm bg-light" style="max-width: 600px;">
    <?= csrf_field() ?>  <!-- Protection CSRF -->

    <h3 class="mb-4 text-center">Ajouter un Filleul</h3>

    <div class="mb-3">
        <label for="nom" class="form-label">Nom</label>
        <input type="text" name="nom" id="nom" class="form-control" value="<?= old('nom') ?>" required>
    </div>
    
     <div class="mb-3">
        <label for="prenom" class="form-label">Prénom</label>
        <input type="text" name="prenom" id="prenom" class="form-control" value="<?= old('prenom') ?>" required>
    </div>

    <div class="mb-3">
        <label for="photo" class="form-label">Photo</label>
        <input type="file" name="photo" id="photo" class="form-control" required>
    </div>

    <div class="text-center">
        <button type="submit" class="btn btn-primary"> Ajouter le Filleul </button>
    </div>
</form>

<script>
function previewImage(event) {
    const preview = document.getElementById('preview');
    preview.src = URL.createObjectURL(event.target.files[0]);
    preview.style.display = 'block';
}
</script>

<?=$this->endsection('content')?>
