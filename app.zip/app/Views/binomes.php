<?= $this->extend('layouts/acceuil') ?>
<?= $this->section('content') ?>
<h2 class="text-center mb-4">Liste complète des Binômes</h2>

<?php if (!empty($binomes)): ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover text-center align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Parrain</th>
                    <th>Photo parrain</th>
                    <th>Filleul</th>
                    <th>Photo Filleul</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($binomes as $b): ?>
                    <tr>
                        <td><?= esc($b['parrain_prenom'] . ' ' . $b['parrain_nom']) ?></td>
                        <td>
                            <img src="<?= base_url('uploads/' . $b['parrain_photo']) ?>" class="rounded-circle" width="50" height="50" style="object-fit:cover;">
                        </td>
                        <td><?= esc($b['filleul_nom']) ?></td>
                        <td>
                            <img src="<?= base_url('uploads/' . $b['filleul_photo']) ?>" class="rounded-circle" width="50" height="50" style="object-fit:cover;">
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="alert alert-info text-center">Aucun binôme à afficher.</div>
<?php endif; ?>

<?= $this->endSection() ?>