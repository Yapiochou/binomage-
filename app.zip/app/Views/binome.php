<?=$this->extend('layouts/acceuil')?>
<!-- [$this->extend('route du fichier template ou principale )] -->
<!-- 'fichier template' c'est le fichier qui contient la page principale -->

<?= $this->section('content') ?>

<h2 class="text-center mb-4">Formation des Binômes</h2>

<div class="d-flex justify-content-center gap-3 mb-4">
    <form action="binomes" method="post">
        <button type="submit" class="btn btn-success">Générer les binômes 🔁</button>
    </form>
   
</div>

<?php if (!empty($binomes)): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>Parrain</th>
                    <th>Filleul</th>
                    <th>Photo Filleul</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($binomes as $b): ?>
                    <tr>
                        <td><?= esc($b['parrain_prenom'] . ' ' . $b['parrain_nom']) ?></td>
                        <td><?= esc($b['filleul_nom']) ?></td>
                        <td>
                            <img src="<?= base_url('uploads/' . $b['filleul_photo']) ?>" class="rounded-circle" width="50" height="50" style="object-fit:cover;">
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-center gap-3 mb-4">
        <form action="dashboard" method="post" onsubmit="return confirm('Voulez-vous vraiment réinitialiser tous les binômes ?')">
            <button type="submit" class="btn btn-danger">Réinitialiser ❌</button>
        </form>
    </div>
<?php else: ?>
    <div class="alert alert-warning text-center">Aucun binôme généré pour le moment.</div>
<?php endif; ?>

<?= $this->endSection() ?>
