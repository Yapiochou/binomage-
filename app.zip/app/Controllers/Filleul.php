<?php

namespace App\Controllers;
use App\Models\FilleulModel;
use CodeIgniter\Controller;

Class Filleul extends Controller
{
    public function creer_filleul()
    {
        return view('filleuls_creer');
    }

    public function ajout_f()
    {
    helper(['form', 'url']);

         // Règles de validation du formulaire
        $validationRule = [
            'nom'   => 'required|min_length[3]',  // Le nom est obligatoire et doit avoir au moins 3 caractères
            'photo' => 'uploaded[photo]|mime_in[photo,image/jpg,image/jpeg,image/png]|max_size[photo,2048]'  // Validation de la photo
        ];

        // Valider les données du formulaire
        if (!$this->validate($validationRule)) {
            return view('filleuls_creer', ['validation' => $this->validator]);
        }
 // Récupération des données envoyées par le formulaire
        $nom = $this->request->getPost('nom');
        $prenom = $this->request->getPost('prenom');
        $photo = $this->request->getFile('photo');

        // Vérification si la photo est valide
        if ($photo->isValid() && !$photo->hasMoved()) {
            // Générer un nom unique pour la photo
            $newName = $photo->getRandomName();
            // Déplacer la photo dans le dossier 'uploads'
            $photo->move('uploads', $newName);

            // Enregistrer les données dans la base de données
            $filleulModel = new FilleulModel();
            $filleulModel->save([
                'nom'    => $nom,
                'prenom' => $prenom,
                'photo'  => $newName  // Le nom de fichier unique de la photo
            ]);

            // Redirection avec un message de succès
            return redirect()->to('filleuls_creer')->with('success', 'Filleul ajouté avec succès !');
        } else {
            // Si l'upload échoue, rediriger avec un message d'erreur
            return redirect()->back()->with('error', 'Erreur lors de l’upload de la photo.');
      
    }
        
}
}