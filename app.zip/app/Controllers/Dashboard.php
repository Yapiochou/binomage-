<?php

namespace App\Controllers;

use App\Models\ParrainModel;
use App\Models\FilleulModel;
use App\Models\BinomeModel;

class Dashboard extends BaseController
{
    // methode index :Cette méthode est appelée pour afficher la page du resultat du tri, récupère toutes les données des parrains, des filleuls, et des binômes.

    public function index()
        {
            $parrainModel = new ParrainModel();
            $filleulModel = new FilleulModel();
            $binomeModel  = new BinomeModel();

            // Récupération des parrains et filleuls
            $data['parrains'] = $parrainModel->findAll();
            $data['filleuls'] = $filleulModel->findAll();
            
            // Récupération des binômes avec les informations supplémentaires
            $data['binomes']  = $binomeModel
                ->select('binomes.*, parrains.nom AS parrain_nom, parrains.prenom AS parrain_prenom, filleuls.nom AS filleul_nom, filleuls.photo AS filleul_photo')
                ->join('parrains', 'parrains.id = binomes.parrain_id')
                ->join('filleuls', 'filleuls.id = binomes.filleul_id')
                ->findAll();

            return view('binome', $data);
        }
/////////////////////////////////////////////
// /////////////////////////////////////
    public function genererBinomes()
{
    $parrainModel = new ParrainModel();
    $filleulModel = new FilleulModel();
    $binomeModel = new BinomeModel();

    // Récupérer les parrains
    $parrains = $parrainModel->findAll();

    // Récupérer les filleuls qui n'ont pas encore été associés à 2 parrains
    $filleuls = $filleulModel
        ->select('filleuls.*, COUNT(binomes.filleul_id) AS binome_count')
        ->join('binomes', 'binomes.filleul_id = filleuls.id', 'left')
        ->groupBy('filleuls.id')
        ->having('binome_count < 2')  // Limiter à ceux qui n'ont pas encore 2 parrains
        ->findAll();

    // Mélanger les parrains pour un assignement aléatoire
    shuffle($parrains);

    // Parcourir les parrains et les assigner aux filleuls
    foreach ($parrains as $parrain) {
        foreach ($filleuls as $filleul) {
            // Vérifier s'il n'existe pas déjà un binôme pour ce parrain et ce filleul
            $existe = $binomeModel
                ->where('parrain_id', $parrain['id'])
                ->where('filleul_id', $filleul['id'])
                ->countAllResults();

            if ($existe == 0) {
                // Assigner le binôme
                $binomeModel->save([
                    'parrain_id' => $parrain['id'],
                    'filleul_id' => $filleul['id']
                ]);
                break;  // Sortir de la boucle interne après l'association
            }
        }
    }

    return redirect()->to('binome');
}

    
     public function resetBinomes()
     {
     $binomeModel = new \App\Models\BinomeModel();
     $binomeModel->truncate(); // Supprime tous les binômes
     return redirect()->to('filleuls_creer')->with('success', 'Tous les binômes ont été réinitialisés.');
     }

     public function deleteBinome($id)
     {
     $binomeModel = new \App\Models\BinomeModel();
     $binomeModel->delete($id);

     return redirect()->to('liste etud')->with('success', 'Binôme supprimé.');
 
    }


public function afficherBinomes()
{
    $binomeModel = new BinomeModel();

    // Récupérer tous les binômes avec les informations de parrain et filleul
    $data['binomes'] = $binomeModel
        ->select('binomes.*, parrains.nom AS parrain_nom, parrains.prenom AS parrain_prenom, filleuls.nom AS filleul_nom, filleuls.photo AS filleul_photo')
        ->join('parrains', 'parrains.id = binomes.parrain_id')
        ->join('filleuls', 'filleuls.id = binomes.filleul_id')
        ->findAll();

    // Retourner la vue avec les données
    return view('binomes', $data);
}

}
