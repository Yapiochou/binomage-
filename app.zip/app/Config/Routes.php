<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/page', 'Home::index');//lien pour acceder à la page d'accueil

$routes->get('binomes', 'Dashboard::index');//lien pour acceder à binome

// route pour les parrains
$routes->get('parrains_creer', 'Parrain::creer_parrain');
$routes->post('adparrain', 'Parrain::ajout_p');

/////////route pour les filleuls//////////////////////
$routes->get('filleuls_creer', 'Filleul::creer_filleul');
$routes->post('/adfilleul', 'Filleul::ajout_f');

$routes->get('/binome', 'Dashboard::genererBinomes');
// $routes->get('liste_etud', 'Parrain::ajout_p');/



// Génération de binômes (formulaire ou bouton)
$routes->post('/genere', 'Dashboard::genererBinomes');

// Supprimer un binôme
$routes->get('/dashboard/(:num)', 'Dashboard::deleteBinome/$1');

// Réinitialiser tous les binômes
$routes->get('/dashboard', 'Dashboard::resetBinomes');


// test
$routes->get('test', 'Test::index');